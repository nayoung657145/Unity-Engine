﻿#pragma strict

var skin : GUISkin;

function Start () {

}

function Update () {

 if(Input.GetButtonDown("Fire1"))
	 Application.LoadLevel("main");

}
function OnGUI() {
	GUI.skin = skin;
	var sw : int = Screen.width;
	var sh : int = Screen.height;
	

	GUI.Label(Rect(0, sh/4, sw, sh/4), "SUPER MARIMO", "title");
	GUI.Label(Rect(0, sh/2, sw, sh/4), "Click to Start", "default");
	
}