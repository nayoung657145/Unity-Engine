﻿#pragma strict

var skin : GUISkin;
var text1 : String;
var text2 : String;

var version : String = "";



function Start () {

}

function Update () {

}

function GameOver(){
	 text1 = "GAME OVER";
	 text2 = "Click to Replay";
	 version = "gameover";
	 
	 while(!Input.GetButtonDown("Fire1"))
	 	yield;
	 Application.LoadLevel("Main");
}

function Win(){
	 text1 = "Congratulations!!";
	 text2 = "Click to Exit";
	 version = "win";
	 
	 while(!Input.GetButtonDown("Fire1"))
	 	yield;
	 Application.LoadLevel("Title");
}

function OnGUI() {
	GUI.skin = skin;
	var sw : int = Screen.width;
	var sh : int = Screen.height;
	if(version == "gameover"){
		GUI.Label(Rect(0, sh/4, sw, sh/4), text1, "gameover");
		GUI.Label(Rect(0, sh/2, sw, sh/4), text2, "default");
	}else if(version == "win"){
		GUI.Label(Rect(0, sh/4, sw, sh/4), text1, "win");
		GUI.Label(Rect(0, sh/2, sw, sh/4), text2, "default");
	}
	
}


