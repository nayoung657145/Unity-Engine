﻿#pragma strict
var walkSpeed :float = 10.0;
var gravity :float = 20.0;
var jumpSpeed :float = 8.0;

var life : int;
var isLive : boolean = true;

var skin : GUISkin;
private var velocity : Vector3;

var jumpSE : AudioClip;
var lifeSE : AudioClip;
var reSE : AudioClip;
var overSE : AudioClip;

function OnGUI() {
	GUI.skin = skin;
	var sw : int = Screen.width;
	var sh : int = Screen.height;
	
	var lifeText : String = "LIFE : " + life.ToString();
	
	GUI.Label(Rect(1, 1, sw/2, sh/4), lifeText, "Life");
}

function OnTriggerEnter(collisionInfo : Collider){
	Debug.Log (collisionInfo.gameObject.name);
	var respawn : GameObject = GameObject.FindWithTag("Respawn");
	
	if(collisionInfo.gameObject.tag == "floor"){
		life -= 1;
		gameObject.transform.position = respawn.transform.position;
		audio.PlayOneShot(lifeSE);
		if(life == 0){
			audio.Stop();
			audio.PlayOneShot(overSE);
			
			isLive = false;
			GameObject.FindWithTag("GameController").SendMessage("GameOver");
		}
	}
	
	if(collisionInfo.gameObject.tag == "Goomba"){
		life -= 1;
		gameObject.transform.position = respawn.transform.position;
		audio.PlayOneShot(lifeSE);
		if(life == 0){
			audio.Stop();
			audio.PlayOneShot(overSE);
			
			isLive = false;
			GameObject.FindWithTag("GameController").SendMessage("GameOver");
		}
	}
	
	if(collisionInfo.gameObject.tag == "Finish"){
		GameObject.FindWithTag("GameController").SendMessage("Win");
	}
}

function Start () {
//	animation["pSphere6|jump001"].speed = 2.0;
	audio.PlayOneShot(reSE);
	isLive = true;
	life = 3;
}

function Update () {
	var controller :CharacterController = GetComponent(CharacterController);
	if(isLive){
		if (controller.isGrounded) {

			velocity = Vector3(-Input.GetAxis("Horizontal"), 0, -Input.GetAxis("Vertical"));
			velocity = transform.TransformDirection(velocity);
			velocity *= walkSpeed;

			if(Input.GetButtonDown("Jump")){
				audio.PlayOneShot(jumpSE);
				velocity.y = jumpSpeed;
				animation.Play("pSphere6|jump");
			}
			else if(velocity.magnitude > 0.5){
				animation.CrossFade("pSphere6|jump.001", 0.1);
			}
		}
		velocity.y -= gravity * Time.deltaTime;
		controller.Move (velocity * Time.deltaTime);
	}
}